package br.com.up.devagaresecalmos

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.com.up.devagaresecalmos.Models.Corrida
import br.com.up.devagaresecalmos.Repository.RaceRepository

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val repository = RaceRepository.instance()

        repository.getAll { races ->


        }

        /* val race = Corrida(
            "402",
            "highway",
            "Toreto",
            12.0f,
            Timestamp.now()
        )

        repository.save(race)*/
    }
}