package br.com.up.devagaresecalmos.Models

import com.google.firebase.Timestamp

data class Corrida (
    val id : String?,
    val distancia : String,
    val localizacao : String,
    val oponente : String,
    val duracao : Number,
    val horario : Timestamp
)
