package br.com.up.devagaresecalmos.Models

data class Usuario(
    val id : String?,
    val nome : String,
    val telefone : String ,
    val carro : String,
    val categoria : String,
    val idade : Number,
    val Whp :  Number
)