package br.com.up.devagaresecalmos.Repository

import android.util.Log
import android.view.inputmethod.CorrectionInfo
import br.com.up.devagaresecalmos.Models.Corrida
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import javax.security.auth.callback.Callback

class RaceRepository {

    companion object{

        private var repository: RaceRepository? = null

        fun instance(): RaceRepository{

            if (repository == null){
                repository = RaceRepository()
            }
            return repository!!
        }

    }

    fun save(race: Corrida){

        val database = Firebase.firestore
        database.collection("corrida").add(race)

    }

    fun delete(race: Corrida){

        val database = Firebase.firestore
        database.collection("corrida").document(race.id!!).delete()

    }

    fun getAll(callback: (List<Corrida>) -> Unit){

        val database = Firebase.firestore
        database.collection("corrida").get().addOnSuccessListener { documents ->
            val races = arrayListOf<Corrida>()
            for (document in documents) {
                val race = Corrida(
                    id = document.id,
                    oponente = document.get("oponente").toString(),
                    localizacao = document.get("localizacao").toString(),
                    distancia = document.get("distancia").toString(),
                    horario = document.getTimestamp("horario")!!,
                    duracao = document.getDouble("duracao")!!.toFloat()
                )
                races.add(race)
            }
            callback(races)
        }

    }

    fun getById(id: String): Corrida{
        TODO()
    }

    fun update(id: String, race: Corrida){

    }
}