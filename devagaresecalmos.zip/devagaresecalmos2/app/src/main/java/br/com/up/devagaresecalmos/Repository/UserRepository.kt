package br.com.up.devagaresecalmos.Repository

import br.com.up.devagaresecalmos.Models.Corrida
import br.com.up.devagaresecalmos.Models.Usuario
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UserRepository {

    companion object{

        private var repository: UserRepository? = null

        fun instance(): UserRepository{

            if (repository == null){
                repository = UserRepository()
            }
            return repository!!
        }

    }
    fun save(user: Usuario){

        val database = Firebase.firestore
        database.collection("usuario").add(user)

    }

    fun delete(user: Usuario){

        val database = Firebase.firestore
        database.collection("usuario").document(user.id!!).delete()

    }

    fun getAll():List<Usuario>{

        val database = Firebase.firestore
        database.collection("usuario").get().addOnSuccessListener { documents -> for (document in documents){
            val users = arrayListOf<Usuario>()
            val user = Usuario(
                id= document.id,
                nome= document.get("nome").toString(),
                telefone= document.get("telefone").toString(),
                carro= document.get("carro").toString(),
                categoria= document.get("categoria").toString(),
                idade= document.getDouble("duracao")!!.toFloat(),
                Whp= document.getDouble("Whp")!!.toFloat()
            )
            users.add(user)
        } }
        return listOf()

    }

    fun getById(id: String): Usuario {

        TODO()

    }

    fun update(id: String, user: Usuario){

    }
}